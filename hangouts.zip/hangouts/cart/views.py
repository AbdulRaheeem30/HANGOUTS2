from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import get_object_or_404
from .models import  Cart

# Create your views here.
def cart_view(request):
    return render(request, 'cart.html')  

@csrf_exempt
def add_to_cart(request):
    if request.method == "POST":
        item_id = request.POST.get("item_id")
        item_name = request.POST.get("item_name")
        price = request.POST.get("price")

        if item_id and price:
            cart_item, created = Cart.objects.get_or_create(item_id=item_id, defaults={'item_name': item_name, 'price': price, 'quantity': 1})
            if not created:
                cart_item.quantity += 1
                cart_item.save()

            return JsonResponse({"success": True, "message": f"{item_name} added to cart!"})

    return JsonResponse({"success": False, "message": "Invalid request"})


