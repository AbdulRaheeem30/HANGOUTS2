from django.db import models

class Cart(models.Model):
    item_name = models.CharField(max_length=255)
    price = models.IntegerField()
    quantity = models.IntegerField(default=1)
