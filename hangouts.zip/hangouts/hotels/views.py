from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import Hotel, Reservation

def hotel_list(request):
    hotels = Hotel.objects.all()
    return render(request, 'hotel_list.html', {'hotels': hotels})

def book_hotel(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)  

    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        date = request.POST.get("date")

        
        Reservation.objects.create(hotel=hotel, name=name, email=email, date=date)

        return HttpResponseRedirect(reverse('hotel_list'))  

    return render(request, 'book_hotel.html', {'hotel': hotel})  
