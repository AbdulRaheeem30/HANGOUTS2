from django.contrib import admin
from django.utils.html import format_html
from .models import Hotel, Reservation

@admin.register(Hotel)
class HotelAdmin(admin.ModelAdmin):
    list_display = ('name', 'location',)  
    search_fields = ('name', 'location')  
    
     
    # def display_image(self, obj):
    #     if obj.image:
    #         return format_html('<img src="{}" width="50" height="50" style="border-radius:5px;" />', obj.image.url)
    #     return "No Image"
    

    # display_image.short_description = "Image Preview"


@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ('hotel', 'name', 'email', 'date')  
    search_fields = ('name', 'email')  
    list_filter = ('hotel', 'date')  
