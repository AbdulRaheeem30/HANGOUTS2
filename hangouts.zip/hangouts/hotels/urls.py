from django.urls import path
from .views import hotel_list, book_hotel

urlpatterns = [
    path('', hotel_list, name='hotel_list'),
    path('<int:hotel_id>/book/', book_hotel, name='book_hotel'),
]
