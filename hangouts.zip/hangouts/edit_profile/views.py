from django.shortcuts import render

def profile(request):
    return render(request, 'edit_profile.html')
