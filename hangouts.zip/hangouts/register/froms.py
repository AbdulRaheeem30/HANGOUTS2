from datetime import date
from django import forms
from django.contrib.auth.models import User
from .models import Profile
from django.core.exceptions import ValidationError

class RegisterForm(forms.ModelForm):
    email = forms.EmailField(required=True)
    birth_date = forms.DateField(required=True, widget=forms.SelectDateWidget(years=range(1900, 2026)))

    class Meta:
        model = User
        fields = ['username', 'password', 'email']

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise ValidationError("Email is already in use.")
        return email

    def clean_birth_date(self):
        birth_date = self.cleaned_data.get('birth_date')
        if birth_date:
            today = date.today()
            if birth_date > today:
                raise ValidationError("Birth date cannot be in the future.")
        return birth_date

    def save(self, commit=True):
        user = super().save(commit=False)
        if commit:
            user.save()
        
        # Create and save the Profile instance
        profile = Profile.objects.create(
            user=user,
            birth_date=self.cleaned_data['birth_date'],
            email=self.cleaned_data['email'],
        )
        return user
