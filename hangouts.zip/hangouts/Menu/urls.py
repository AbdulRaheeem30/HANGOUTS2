from django.urls import path
from .views import *

app_name='menu'
urlpatterns = [
    path('menu/<int:id>/', menu, name='menu'),
    path('veg/<int:id>/', veg, name='veg'),
    path('nonveg/<int:id>/', nonveg, name='nonveg'),

]
