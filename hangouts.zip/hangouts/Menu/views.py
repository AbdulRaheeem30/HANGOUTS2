from django.shortcuts import render
from .models import *

def menu(request, id=None):
    if id:
        data = Menu.objects.filter(id=id)
    else:
        data = Menu.objects.all()  

    return render(request, 'menu.html', {'data': data})


def veg(request,id):
    data=Menu.objects.get(id=id)
    return render(request, 'veg.html', {'data': data} )

def nonveg(request,id):
    data=Menu.objects.get(id=id)
    return render(request, 'nonveg.html', {'data': data} )

































































































































































































































# def add_to_cart(request):
#     if request.method == 'POST':
#         item_id = request.POST.get('item_id')
#         quantity = int(request.POST.get('quantity', 1))
#         item = get_object_or_404(MenuItem, id=item_id)

#         cart = request.session.get('cart', {})

#         if str(item_id) in cart:
#             cart[str(item_id)]['quantity'] += quantity
#             if cart[str(item_id)]['quantity'] <= 0:
#                 del cart[str(item_id)]
#         else:
#             if quantity > 0:
#                 cart[str(item_id)] = {'name': item.name, 'price': str(item.price), 'quantity': quantity}

#         request.session['cart'] = cart
#         request.session.modified = True

#         total_price = sum(float(item['price']) * item['quantity'] for item in cart.values())

#         return JsonResponse({"cart": cart, "total_price": total_price})

#     return JsonResponse({"error": "Invalid request"}, status=400)

# def remove_from_cart(request):
#     if request.method == 'POST':
#         item_id = request.POST.get('item_id')
#         cart = request.session.get('cart', {})

#         if str(item_id) in cart:
#             del cart[str(item_id)]
#             request.session['cart'] = cart
#             request.session.modified = True

#         total_price = sum(float(item['price']) * item['quantity'] for item in cart.values())

#         return JsonResponse({"cart": cart, "total_price": total_price})

#     return JsonResponse({"error": "Item not found"}, status=400)

# def cart(request):
#     cart = request.session.get('cart', {})
#     total_price = sum(float(item['price']) * item['quantity'] for item in cart.values())

#     return render(request, 'cart.html', {'cart_items': cart, 'total_price': total_price})

# def checkout(request):
#     cart = request.session.get('cart', {})

#     if not cart:
#         return JsonResponse({"error": "Cart is empty!"}, status=400)

#     for item_id, item_data in cart.items():
#         menu_item = get_object_or_404(MenuItem, id=int(item_id))
#         OrderItem.objects.create(item=menu_item, quantity=item_data['quantity'])

#     request.session['cart'] = {}  # Clear cart after checkout
#     request.session.modified = True

#     return JsonResponse({"message": "Order placed successfully!"})
