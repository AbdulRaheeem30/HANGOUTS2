from django.urls import path
from .views import *

app_name='veg'
urlpatterns = [
    path('veg/',veg, name='veg')
]
