from django.db import models

class NonVeg(models.Model):
    name=models.CharField( max_length=100)
    desc=models.CharField( max_length=50)
    pic=models.ImageField(upload_to='nonveg_pic/')
    

    def __str__(self):
        return self.name


