from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .forms import UserRegistrationForm, UserLoginForm
from .models import UserProfile

def register(request):
    if request.method == "POST":
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            UserProfile.objects.create(user=user)
            messages.success(request, "Registration successful! You can log in now.")
            return redirect("/signup/login/")
    else:
        form = UserRegistrationForm()
    return render(request, "register.html", {"form": form})

def user_login(request):
    if request.method == "POST":
        form = UserLoginForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate (username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect("home")
            else:
                messages.error(request, "Invalid credentials!")
    else:
        form = UserLoginForm()
    return render(request, "login.html", {"form": form})

def user_logout(request):
    logout(request)
    return redirect("login")

def profile(request):
    if not request.user.is_authenticated:
        return redirect("login")
    
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)
    if request.method == "POST":
        request.user.username = request.POST.get("name")
        request.user.email = request.POST.get("email")
        user_profile.phone = request.POST.get("phone")
        user_profile.location = request.POST.get("location")
        request.user.save()
        user_profile.save()
        messages.success(request, "Profile updated successfully!")
    return render(request, "profile.html", {"user_profile": user_profile})

def signup(request):
    return render(request, "signup.html")